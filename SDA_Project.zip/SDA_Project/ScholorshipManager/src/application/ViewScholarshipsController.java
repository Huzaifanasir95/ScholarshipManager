package application;

public class ViewScholarshipsController {
    // Empty class - no functionality required for UI-only.
}
